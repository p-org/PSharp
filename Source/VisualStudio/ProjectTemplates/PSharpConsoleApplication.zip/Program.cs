﻿using System;
using System.Collections.Generic;
using Microsoft.PSharp;

namespace $safeprojectname$
{
    public class Program
    {
        static void Main(string[] args)
        {
            Runtime.RegisterNewMachine(typeof(Machine));

            Runtime.Start();
            Runtime.Wait();
            Runtime.Dispose();
        }
    }
}
